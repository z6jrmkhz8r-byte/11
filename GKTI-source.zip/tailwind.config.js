/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: {
          50: '#FAF3E3',
          100: '#F2E8D5',
          200: '#E8DCC0',
          300: '#D9C9A3',
          400: '#C9B68F',
        },
        ink: {
          red: '#A93226',
          'red-d': '#7B1F1A',
          blue: '#1F3A5F',
          'blue-d': '#14263F',
        },
        text1: '#2B2113',
        text2: '#5C4A30',
        text3: '#8C7656',
        line: '#C9B68F',
        highlight: '#E8C547',
      },
      fontFamily: {
        serif: ['"Noto Serif SC"', '"Source Han Serif SC"', 'serif'],
        wenkai: ['"LXGW WenKai"', '"Noto Serif SC"', 'serif'],
        mono: ['"Space Mono"', '"JetBrains Mono"', 'ui-monospace', 'monospace'],
        sans: ['"Noto Sans SC"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        paper: '0 1px 0 rgba(43,33,19,0.08), 0 6px 14px -8px rgba(43,33,19,0.25)',
        stamp: '0 0 0 2px rgba(169,50,38,0.15), inset 0 0 0 2px rgba(169,50,38,0.4)',
      },
    },
  },
  plugins: [],
};
