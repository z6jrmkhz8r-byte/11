import { Route, Routes, useLocation } from 'react-router-dom';
import PhoneFrame from './components/PhoneFrame';
import HomePage from './pages/HomePage';
import RulesPage from './pages/RulesPage';
import QuizPage from './pages/QuizPage';
import ResultLoadingPage from './pages/ResultLoadingPage';
import ResultPage from './pages/ResultPage';
import TransitionMask from './components/TransitionMask';

function GKTIRoutes() {
  const location = useLocation();
  /*
   * 不再用 key={location.pathname} 强制卸载重建；
   * 让路由切换时尽量保留组件树（QuizPage 内部用更细粒度的 key 控制题干 / 选项动画），
   * 避免出现"全屏刷新"观感。
   */
  return (
    <div className="h-full">
      <Routes location={location}>
        <Route path="/" element={<HomePage />} />
        <Route path="/rules" element={<RulesPage />} />
        <Route path="/quiz/:n" element={<QuizPage />} />
        <Route path="/loading" element={<ResultLoadingPage />} />
        <Route path="/result" element={<ResultPage />} />
      </Routes>
    </div>
  );
}

/**
 * 全平台统一 H5 单屏：PC 与移动端都渲染同一张卡片，
 * 卡片内即完整 H5，所有交互在内部完成。
 */
export default function App() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center px-2 py-2">
      <PhoneFrame fullscreen>
        <GKTIRoutes />
      </PhoneFrame>
      <TransitionMask />
    </div>
  );
}
