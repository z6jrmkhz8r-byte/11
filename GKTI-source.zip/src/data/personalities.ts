/**
 * 4 字母人格代码：
 *   1: O 乐观 / X 悲观
 *   2: T 应试 / I 临场 (Improv)
 *   3: M 玄学 / S 实力
 *   4: P 抗压 / F 易碎
 *
 * 但为贴合截图"CCCC"梗，我们不直接显示字母维度，
 * 而是把 5 维结果汇总后映射为 10 个有戏剧效果的"代号"。
 *
 * 设计图中的代号示例：CCCC、A4.exe、Math404、UP2AH!?、HIDEPro、ALLin!?、HEX-1、CPU.MAX、LUCK++
 */

export interface Personality {
  code: string;
  title: string;
  tags: string[];
  desc: string;
  /** 5 维向量分数倾向（用于匹配，非展示） */
  vec: { O: number; T: number; M: number; P: number; S: number };
}

export const PERSONALITIES: Personality[] = [
  {
    code: 'CCCC',
    title: '不会就选 C 型',
    tags: ['乐观', '临场派', '玄学稳定发挥'],
    desc: '你相信感受，也相信运气，更相信自己。\n遇事不慌，主打一个心态稳，搭配 C，选择稳合一！\n高考也是人生的一场游戏，你早已悄悄佩服自己。',
    vec: { O: 2, T: -1, M: 1, P: 2, S: 0 },
  },
  {
    code: 'A4.exe',
    title: '考前白纸型',
    tags: ['理性', '应试派', '实战至上'],
    desc: '一张白纸进考场，一沓答案出考场。\n你不靠灵感，不靠运气，只靠肌肉记忆。\n稳扎稳打，绝不感情用事——这就是 A4 的修养。',
    vec: { O: 0, T: 2, M: -2, P: 1, S: -1 },
  },
  {
    code: 'Math404',
    title: '一看就废型',
    tags: ['可爱', '随缘派', '能蒙就蒙'],
    desc: '题目对你说："找不到此页面"。\n但你毫不在意，反正人生不止一场考试。\n上天给你关了一扇数学的门，必然为你打开物理的窗（也许）。',
    vec: { O: 1, T: -2, M: 1, P: 0, S: 1 },
  },
  {
    code: 'UP2AH!?',
    title: '逆天改命型',
    tags: ['悲壮', '通宵党', '永不放弃'],
    desc: '凌晨四点的台灯下，是你不甘的眼神。\nUp to ah?! 哪怕只剩一周，也要把高三逆袭出花。\n你是教辅书最忠实的朋友，也是床的最熟陌生人。',
    vec: { O: 0, T: 1, M: -1, P: -1, S: -1 },
  },
  {
    code: 'LUCK++',
    title: '玄学锦鲤型',
    tags: ['乐观', '锦鲤体质', '神秘力量'],
    desc: '你身上有红绳、水晶、考神挂件、转发的 999 张锦鲤。\n知识可以遗忘，但好运不会缺席。\n你坚信：努力是基础，运气才是上限。',
    vec: { O: 2, T: 0, M: 2, P: 1, S: 0 },
  },
  {
    code: 'HIDEPro',
    title: '深藏不露型',
    tags: ['内敛', '独行派', '蓄势待发'],
    desc: '你不爱对答案，不喜欢热闹，连交卷都低调。\n看似平平无奇，分数出来全班沉默。\n安静，是你最大的杀手锏。',
    vec: { O: 0, T: 1, M: 0, P: 2, S: -2 },
  },
  {
    code: 'ALLin!?',
    title: '孤注一掷型',
    tags: ['热血', '临场派', '梭哈选手'],
    desc: '别人在分析难度，你已经写完一道大题。\n不留余地，不留后路，要么上岸，要么重来。\n这种气势，连答题卡都怕你。',
    vec: { O: 1, T: -1, M: -1, P: -1, S: 1 },
  },
  {
    code: 'HEX-1',
    title: '神秘代号型',
    tags: ['冷静', '理性派', '极简主义'],
    desc: '你不信玄学，也不爱热闹，只信公式与逻辑。\n每一道题在你眼里都是一行待执行的代码。\n报错？重启大脑，重新推导。',
    vec: { O: -1, T: 2, M: -2, P: 1, S: -1 },
  },
  {
    code: 'CPU.MAX',
    title: '高负荷运转型',
    tags: ['卷王', '应试派', '满载运行'],
    desc: '别人在午休，你在做最后一套模拟。\n你不是在学习，就是在去学习的路上。\n警告：CPU 占用率 100%，请考虑给自己留一点余温。',
    vec: { O: -1, T: 2, M: -1, P: 0, S: -1 },
  },
  {
    code: 'GG.WP',
    title: '佛系交卷型',
    tags: ['豁达', '随缘派', '即兴发挥'],
    desc: '考试 60 分钟，你 30 分钟交卷。\n不是你会，而是你不卷。\n人生重要的事情有很多，高考只是其中一件——你早就想通了。',
    vec: { O: 1, T: -2, M: 0, P: 2, S: 1 },
  },
];

/**
 * 计算结果：5 维 -> 找最近向量
 */
export function pickPersonality(score: { O: number; T: number; M: number; P: number; S: number }) {
  let best = PERSONALITIES[0];
  let bestDist = Infinity;
  for (const p of PERSONALITIES) {
    const d =
      (p.vec.O - score.O) ** 2 +
      (p.vec.T - score.T) ** 2 +
      (p.vec.M - score.M) ** 2 +
      (p.vec.P - score.P) ** 2 +
      (p.vec.S - score.S) ** 2;
    if (d < bestDist) {
      bestDist = d;
      best = p;
    }
  }
  return best;
}
