/**
 * 5 个维度（每题打到 1 个维度，影响 ±1）：
 *   O = Optimism      乐观 vs 悲观     (Optimist / Pessimist)
 *   T = Tactic        应试 vs 临场     (Tactic / Improv)
 *   M = Mystic        玄学 vs 实力     (Mystic / Skill)
 *   P = Pressure      抗压 vs 易崩     (Pressure-proof / Fragile)
 *   S = Social        合群 vs 孤勇     (Social / Solo)
 *
 * 每题 4 个选项 -> 在某维度 +1 / -1 / 0 / 0
 */

export type Dim = 'O' | 'T' | 'M' | 'P' | 'S';
export type Choice = 'A' | 'B' | 'C' | 'D';

export interface Question {
  id: number;
  text: string;
  options: Record<Choice, string>;
  /** 该题影响的维度；选项对应权重（A,B,C,D 顺序） */
  dim: Dim;
  weights: [number, number, number, number];
}

export const QUESTIONS: Question[] = [
  {
    id: 1,
    text: '凌晨 1 点，你正在做什么？',
    options: {
      A: '刚打开课本，今晚必须逆天改命',
      B: '已经睡了，明天按计划继续',
      C: '假装睡觉，被窝里偷偷刷题',
      D: '在转发"高考必过"锦鲤',
    },
    dim: 'M',
    weights: [-1, 0, 0, 1],
  },
  {
    id: 2,
    text: '考试还有 5 分钟，你会？',
    options: {
      A: '再背一道公式',
      B: '看窗外发呆',
      C: '检查准考证',
      D: '问同桌你紧张吗',
    },
    dim: 'T',
    weights: [1, -1, 1, 0],
  },
  {
    id: 3,
    text: '考前一晚，妈妈进屋问你紧不紧张，你的回答是？',
    options: {
      A: '不紧张，稳得很',
      B: '一般，平常心',
      C: '紧张，但不想说',
      D: '我能不能不去？',
    },
    dim: 'P',
    weights: [1, 0, -1, -1],
  },
  {
    id: 4,
    text: '拿到试卷的第一件事？',
    options: {
      A: '从头到尾扫一眼难度',
      B: '直接做第一题',
      C: '深呼吸三次',
      D: '默念一句"祖师爷保佑"',
    },
    dim: 'M',
    weights: [0, 1, 0, -1],
  },
  {
    id: 5,
    text: '遇到完全不会的题，你的反应？',
    options: {
      A: '蒙一个 C，不会就选 C',
      B: '空着，先做后面',
      C: '硬想，不放弃',
      D: '心态炸了，想交卷',
    },
    dim: 'P',
    weights: [0, 1, 1, -1],
  },
  {
    id: 6,
    text: '考试中铅笔突然断了，你？',
    options: {
      A: '冷静换一支，眼皮都不抬',
      B: '小心捡起来，磕磕巴巴削',
      C: '跟监考老师借',
      D: '心里咯噔一下，开始胡思乱想',
    },
    dim: 'P',
    weights: [1, 0, 0, -1],
  },
  {
    id: 7,
    text: '考完一科，同学说答案和你不一样，你？',
    options: {
      A: '不对答案，下一科见',
      B: '听一耳朵，赶紧跑',
      C: '当场掏出笔验证',
      D: '心态崩了，开始怀疑人生',
    },
    dim: 'O',
    weights: [1, 1, 0, -1],
  },
  {
    id: 8,
    text: '作文题不会写，你的处理是？',
    options: {
      A: '编一个名人名言开局',
      B: '老老实实写真情实感',
      C: '套用万能模板',
      D: '硬凑字数到结尾',
    },
    dim: 'T',
    weights: [0, -1, 1, 0],
  },
  {
    id: 9,
    text: '走进考场前，你身上有什么？',
    options: {
      A: '一支幸运笔',
      B: '父母塞的红绳',
      C: '只有准考证和身份证',
      D: '一颗紧握的水晶',
    },
    dim: 'M',
    weights: [1, 1, -1, 1],
  },
  {
    id: 10,
    text: '中午午休你会？',
    options: {
      A: '雷打不动睡 30 分钟',
      B: '睡不着，盯着天花板',
      C: '再翻一遍错题本',
      D: '和同学聊天放松',
    },
    dim: 'T',
    weights: [1, -1, 1, 0],
  },
  {
    id: 11,
    text: '考试期间最怕遇到？',
    options: {
      A: '突然停电',
      B: '忘带 2B 铅笔',
      C: '隔壁同学一直抖腿',
      D: '我自己拉肚子',
    },
    dim: 'S',
    weights: [0, 0, -1, 0],
  },
  {
    id: 12,
    text: '出考场后，你最想做什么？',
    options: {
      A: '立刻睡到地老天荒',
      B: '和爸妈大餐一顿',
      C: '一个人静静',
      D: '冲网吧/KTV',
    },
    dim: 'S',
    weights: [0, 1, -1, 1],
  },
  {
    id: 13,
    text: '如果可以给考前的自己一句话？',
    options: {
      A: '你比你想象的更强',
      B: '稳住，别浪',
      C: '考砸了也没关系',
      D: '别想了，去睡吧',
    },
    dim: 'O',
    weights: [1, 0, -1, 0],
  },
];
