import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Choice, QUESTIONS } from '@/data/questions';
import { calcResult } from '@/utils/calcResult';
import { Personality } from '@/data/personalities';

interface QuizState {
  answers: Record<number, Choice>;
  currentIndex: number;
  result: Personality | null;
  isAdvancing: boolean;
  setAnswer: (q: number, c: Choice) => void;
  goto: (n: number) => void;
  next: () => void;
  prev: () => void;
  setAdvancing: (v: boolean) => void;
  computeResult: () => Personality;
  reset: () => void;
}

export const useQuizStore = create<QuizState>()(
  persist(
    (set, get) => ({
      answers: {},
      currentIndex: 1,
      result: null,
      isAdvancing: false,
      setAnswer: (q, c) => set((s) => ({ answers: { ...s.answers, [q]: c } })),
      goto: (n) =>
        set({
          currentIndex: Math.max(1, Math.min(QUESTIONS.length, n)),
          isAdvancing: false,
        }),
      next: () =>
        set((s) => ({
          currentIndex: Math.min(QUESTIONS.length, s.currentIndex + 1),
          isAdvancing: false,
        })),
      prev: () =>
        set((s) => ({
          currentIndex: Math.max(1, s.currentIndex - 1),
          isAdvancing: false,
        })),
      setAdvancing: (v) => set({ isAdvancing: v }),
      computeResult: () => {
        const r = calcResult(get().answers);
        set({ result: r });
        return r;
      },
      reset: () =>
        set({ answers: {}, currentIndex: 1, result: null, isAdvancing: false }),
    }),
    {
      name: 'gkti-quiz',
      // 只持久化最终结果，避免 answers 在下次打开时回显造成
      // "进入答题就预填 / 自动选 D / 自动填涂" 的错觉。
      partialize: (state) => ({ result: state.result }),
      version: 2,
      // 旧版本（v1 及之前）持久化了完整 answers/currentIndex，
      // 升级到 v2 时一次性丢弃这些字段，仅保留 result。
      migrate: (persisted: unknown) => {
        const p = (persisted ?? {}) as { result?: Personality | null };
        return { result: p.result ?? null } as Partial<QuizState>;
      },
    },
  ),
);
