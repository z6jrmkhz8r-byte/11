import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import * as htmlToImage from 'html-to-image';
import PrimaryButton from '@/components/PrimaryButton';
import PillBadge from '@/components/PillBadge';
import { useQuizStore } from '@/store/useQuizStore';
import { Download, Share2 } from 'lucide-react';

export default function ResultPage() {
  const nav = useNavigate();
  const { result, computeResult } = useQuizStore();
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!result) computeResult();
  }, [result, computeResult]);

  const data = result || computeResult();
  const today = new Date(2026, 5, 7);

  const handleSave = async () => {
    if (!cardRef.current) return;
    try {
      const dataUrl = await htmlToImage.toPng(cardRef.current, {
        pixelRatio: 2,
        backgroundColor: '#F7ECD6',
      });
      const link = document.createElement('a');
      link.download = `GKTI-${data.code}.png`;
      link.href = dataUrl;
      link.click();
    } catch (e) {
      console.error(e);
    }
  };

  const handleShare = async () => {
    const text = `我的高考人格是 ${data.code} · ${data.title}！来 GKTI 测测你的高考人格 → ${location.origin}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'GKTI 高考人格测试', text, url: location.origin });
      } catch {}
    } else {
      try {
        await navigator.clipboard.writeText(text);
        alert('分享文案已复制到剪贴板');
      } catch {}
    }
  };

  return (
    <div
      ref={cardRef}
      className="flex h-full flex-col overflow-hidden"
      style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}
    >
      {/* —— 顶部留白：避免"★ 你的高考人格类型是 ★"贴红框上沿 —— */}
      <div className="shrink-0" style={{ height: 16 }} />

      {/* —— 类型说明小字（顶部"2026 人格准考证"行与虚线已移除） —— */}
      <p className="shrink-0 text-center font-serif text-[10.5px] tracking-[0.28em] text-text1">
        ★ 你 的 高 考 人 格 类 型 是 ★
      </p>

      {/* —— 大字代码（缩到不会触红框） —— */}
      <h1
        className="my-1 shrink-0 text-center font-serif font-black leading-[0.95] tracking-[0.04em] text-ink-red"
        style={{
          fontSize: 'clamp(38px, 11vw, 60px)',
          WebkitTextStroke: '0.5px #7B1F1A',
          textShadow: '2px 2px 0 rgba(169,50,38,0.12)',
        }}
      >
        {data.code}
      </h1>

      {/* —— 中文标题（缩字号 + 收紧 tracking 防溢出） —— */}
      <h2 className="mt-1 shrink-0 text-center font-serif text-[15px] font-bold tracking-[0.18em] text-text1">
        {data.title}
      </h2>

      {/* —— 标签 —— */}
      <div className="mt-2 flex shrink-0 flex-wrap justify-center gap-1.5">
        {data.tags.map((t, i) => (
          <PillBadge
            key={t}
            tilt={i % 2 === 0 ? 'l' : 'r'}
            variant={i === 1 ? 'red' : 'blue'}
          >
            {t}
          </PillBadge>
        ))}
      </div>

      {/* —— 描述（弹性区，超出可滚） —— */}
      <p className="mt-2 min-h-0 flex-1 overflow-y-auto whitespace-pre-line font-serif text-[10.5px] leading-[1.55] tracking-normal text-text1">
        {data.desc}
      </p>

      {/* —— 元信息 —— */}
      <div className="mt-2 shrink-0 border-t border-dashed border-text2/40 pt-1.5 font-serif text-[10px] tracking-normal text-text1">
        <div className="flex">
          <span className="w-14 shrink-0 text-text2">座位号</span>
          <span>2026</span>
        </div>
        <div className="mt-0.5 flex">
          <span className="w-14 shrink-0 text-text2">发证日期</span>
          <span className="min-w-0 flex-1">
            那个改变人生的夏天
            <span className="ml-1 font-mono text-text3">
              ({today.getFullYear()}.{String(today.getMonth() + 1).padStart(2, '0')}.
              {String(today.getDate()).padStart(2, '0')})
            </span>
          </span>
        </div>
      </div>

      {/* —— 按钮区 —— */}
      <div className="mt-2 grid shrink-0 grid-cols-2 gap-2">
        <PrimaryButton
          variant="red"
          onClick={handleSave}
          className="!px-1 !py-1.5 !text-[10.5px] !tracking-wider"
        >
          <Download className="mr-1 inline-block h-3.5 w-3.5" />
          保存准考证
        </PrimaryButton>
        <PrimaryButton
          variant="blue"
          onClick={handleShare}
          className="!px-1 !py-1.5 !text-[10.5px] !tracking-wider"
        >
          <Share2 className="mr-1 inline-block h-3.5 w-3.5" />
          分享给好友
        </PrimaryButton>
      </div>

      <button
        onClick={() => {
          useQuizStore.getState().reset();
          nav('/');
        }}
        className="mt-1 shrink-0 self-center font-mono text-[9.5px] tracking-widest text-text3 underline-offset-4 hover:underline"
      >
        重新测试 →
      </button>
    </div>
  );
}
