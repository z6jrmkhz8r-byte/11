import { useNavigate } from 'react-router-dom';
import AnswerCardHeader from '@/components/AnswerCardHeader';
import PrimaryButton from '@/components/PrimaryButton';
import { useQuizStore } from '@/store/useQuizStore';

export default function RulesPage() {
  const nav = useNavigate();
  const reset = useQuizStore((s) => s.reset);
  return (
    <div className="flex h-full flex-col">
      {/* —— 答题卡头部（与 QuizPage 同源） —— */}
      <AnswerCardHeader />

      {/* —— 选择题分隔栏 —— */}
      <div className="my-3 flex items-center gap-2">
        <span className="h-px flex-1 bg-ink-red" />
        <span className="font-serif text-[11px] font-bold tracking-[0.5em] text-text1">
          选择题
        </span>
        <span className="h-px flex-1 bg-ink-red" />
      </div>

      {/* —— 示例 / 规则说明区 —— */}
      <div className="space-y-2.5 border border-text1/80 bg-paper-50/30 paper-noise px-3 py-3">
        <div className="flex items-start gap-2">
          <span className="mt-1 inline-block h-2 w-2 shrink-0 bg-text1" />
          <p className="font-serif text-[12px] leading-relaxed text-text1">
            <span className="font-bold">共 13 题</span>
            ，每题 4 个选项，选择最贴近真实你的一项。
          </p>
        </div>
        <div className="flex items-start gap-2">
          <span className="mt-1 inline-block h-2 w-2 shrink-0 bg-text1" />
          <p className="font-serif text-[12px] leading-relaxed text-text1">
            点选后<span className="font-bold">自动跳转下一题</span>
            ，可点击「上一题」回退修改。
          </p>
        </div>
        <div className="flex items-start gap-2">
          <span className="mt-1 inline-block h-2 w-2 shrink-0 bg-text1" />
          <p className="font-serif text-[12px] leading-relaxed text-text1">
            完成全部题目后，进入<span className="font-bold">人格批改</span>
            环节，得到专属高考人格。
          </p>
        </div>
      </div>

      {/* —— 我已了解按钮（紧贴规则说明下方） —— */}
      <div className="mt-3">
        <PrimaryButton
          variant="blue"
          block
          onClick={() => {
            // 进入新一轮答题前清空旧答案，避免持久化残留导致预填/"自动选 D"
            reset();
            nav('/quiz/1');
          }}
        >
          我已了解，开始答题
        </PrimaryButton>
      </div>

      {/* —— 底部红色虚线提示（推到底部） —— */}
      <div className="mt-auto pt-3">
        <div className="border-t border-dashed border-ink-red" />
        <p className="mt-1 text-center font-serif text-[10px] leading-tight text-ink-red">
          请在各题目的答题区域内作答，超出黑色矩形边框限定区域的答案无效
        </p>
      </div>
    </div>
  );
}
