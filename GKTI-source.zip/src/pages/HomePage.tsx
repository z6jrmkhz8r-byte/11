import { useNavigate } from 'react-router-dom';
import PrimaryButton from '@/components/PrimaryButton';
import { GraduationCap } from 'lucide-react';
import admitCardImg from '@/assets/admit-card.png';

export default function HomePage() {
  const nav = useNavigate();
  return (
    <div className="flex h-full flex-col items-center">
      {/* —— 顶部留白：让顶部组件整体下移，避免"中国高考限定"贴红框线 —— */}
      <div style={{ height: 18 }} />

      {/* —— 顶部徽章 —— */}
      <div className="flex justify-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-text1/70 bg-paper-50/70 px-3 py-1 font-serif text-[11px] tracking-wide text-text1">
          <span className="text-ink-red">★</span>
          中国高考限定 · 独家人格测试
          <span className="text-ink-red">★</span>
        </span>
      </div>

      {/* —— LOGO 块（GKTI / 副标题 / 说明）—— */}
      <div className="relative text-center" style={{ marginTop: 21 }}>
        <GraduationCap
          className="absolute right-2 top-1 h-5 w-5 text-text1"
          strokeWidth={1.5}
        />
        <span className="absolute left-1 top-2 text-[12px] text-ink-red">★</span>
        <span className="absolute right-3 top-10 text-[10px] text-ink-red/70">
          ★
        </span>
        <h1 className="font-mono text-[56px] font-bold leading-none tracking-[0.04em] text-ink-red">
          GKTI
        </h1>
        <h2
          className="font-serif text-[17px] font-bold tracking-[0.42em] text-text1"
          style={{ marginTop: 7 }}
        >
          高考人格测试
        </h2>
        <p
          className="font-serif text-[11px] tracking-wide text-text2"
          style={{ marginTop: 7 }}
        >
          13 道题 · 五维人格扫描，测出你的
          <span className="mx-1 inline-block bg-highlight/70 px-1 font-bold text-text1">
            高考人格
          </span>
        </p>
      </div>

      {/* —— 准考证图（视觉中心）—— */}
      <div className="mt-3 flex w-full justify-center">
        <img
          src={admitCardImg}
          alt="GKTI 准考证"
          className="block w-full select-none"
          style={{
            filter: 'drop-shadow(0 8px 18px rgba(43,33,19,0.22))',
            transform: 'scale(1.18) rotate(-1.2deg)',
            transformOrigin: 'center center',
          }}
          draggable={false}
        />
      </div>

      {/* —— 开始测试按钮（独立 wrapper：放大 1.2 + 负 margin 上移，紧贴准考证） —— */}
      <div
        className="flex flex-col items-center"
        style={{
          marginTop: -10,
          transform: 'scale(1.2)',
          transformOrigin: 'top center',
        }}
      >
        <PrimaryButton
          variant="red"
          className="vintage-cta"
          onClick={() => nav('/rules')}
        >
          开 始 测 试 →
        </PrimaryButton>
      </div>

      {/* —— 倒计时（独立 wrapper：相对按钮组下移一些，与按钮拉开间距） —— */}
      <div
        className="flex flex-col items-center"
        style={{
          marginTop: 14,
          transform: 'scale(1.2)',
          transformOrigin: 'top center',
        }}
      >
        <div className="inline-flex items-center gap-1.5 border border-line bg-paper-50/40 px-2.5 py-1 font-serif text-[10.5px] text-text2">
          <span className="h-1.5 w-1.5 rounded-full bg-ink-red" />
          距 2026 年高考还有
          <span className="font-mono font-bold text-ink-red">12</span>天
        </div>
      </div>

      {/* —— 底部弹性留白 —— */}
      <div className="flex-1" />
    </div>
  );
}
