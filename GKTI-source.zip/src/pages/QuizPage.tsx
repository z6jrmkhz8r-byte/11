import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import AnswerCardHeader from '@/components/AnswerCardHeader';
import QuizOption from '@/components/QuizOption';
import ProgressBar from '@/components/ProgressBar';
import { QUESTIONS, Choice } from '@/data/questions';
import { useQuizStore } from '@/store/useQuizStore';

const AUTO_ADVANCE_MS = 480;

export default function QuizPage() {
  const { n } = useParams();
  const nav = useNavigate();
  const num = Math.max(1, Math.min(QUESTIONS.length, Number(n) || 1));
  const q = QUESTIONS[num - 1];

  const { answers, setAnswer, goto, isAdvancing, setAdvancing } = useQuizStore();
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    goto(num);
    setAdvancing(false);
    return () => {
      if (timerRef.current != null) {
        window.clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [num, goto, setAdvancing]);

  const answeredSet = useMemo(() => {
    const s = new Set<number>();
    Object.keys(answers).forEach((k) => {
      if (answers[Number(k)]) s.add(Number(k));
    });
    return s;
  }, [answers]);

  const [fastFill, setFastFill] = useState(false);
  useEffect(() => {
    setFastFill(answers[q.id] !== undefined);
  }, [num, q.id]); // eslint-disable-line

  const onChoose = (c: Choice) => {
    if (isAdvancing) return;
    setAnswer(q.id, c);
    setAdvancing(true);
    setFastFill(false);

    if (timerRef.current != null) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      timerRef.current = null;
      if (num >= QUESTIONS.length) {
        nav('/loading');
      } else {
        nav(`/quiz/${num + 1}`);
      }
    }, AUTO_ADVANCE_MS);
  };

  const onPrev = () => {
    if (num <= 1) return;
    if (timerRef.current != null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setAdvancing(false);
    nav(`/quiz/${num - 1}`);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const map: Record<string, Choice> = {
        a: 'A', b: 'B', c: 'C', d: 'D',
        '1': 'A', '2': 'B', '3': 'C', '4': 'D',
      };
      const c = map[e.key.toLowerCase()];
      if (c) onChoose(c);
      if (e.key === 'ArrowLeft') onPrev();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line
  }, [num, isAdvancing]);

  return (
    <div className="quiz-paper flex h-full flex-col">
      {/* —— 答题卡头 —— */}
      <AnswerCardHeader />

      {/* 选择题分隔栏 */}
      <div className="my-2 flex items-center gap-2">
        <span className="h-px flex-1 bg-ink-red" />
        <span className="font-serif text-[11px] font-bold tracking-[0.5em] text-text1">
          选择题
        </span>
        <span className="h-px flex-1 bg-ink-red" />
      </div>

      {/* 进度条 */}
      <ProgressBar
        total={QUESTIONS.length}
        current={num}
        answered={answeredSet}
        quickFilled={answeredSet}
        onJump={(k) => {
          if (timerRef.current != null) window.clearTimeout(timerRef.current);
          setAdvancing(false);
          nav(`/quiz/${k}`);
        }}
      />

      {/* 题号标识 ■ Q3（固定黑色实体方块，无动画） */}
      <div className="mt-3 flex items-center gap-1.5">
        <span className="inline-block h-2.5 w-2.5 bg-text1" aria-hidden />
        <span className="font-mono text-[13px] font-bold tracking-wide text-text1">
          Q{num}
        </span>
      </div>

      {/* 题干 */}
      <div
        key={`q-${num}`}
        className="quiz-question-in mt-1.5 border border-text1/85 bg-paper-50/30 px-2.5 py-2"
      >
        <h3 className="font-serif text-[14px] font-bold leading-snug text-text1">
          {q.text}
        </h3>
      </div>

      {/* 选项 */}
      <div key={`opts-${num}`} className="mt-2 space-y-1.5">
        {(['A', 'B', 'C', 'D'] as Choice[]).map((c) => (
          <div key={c} className="option-in">
            <QuizOption
              label={c}
              text={q.options[c]}
              selected={answers[q.id] === c}
              fastFill={fastFill && answers[q.id] === c}
              disabled={isAdvancing && answers[q.id] !== c}
              onSelect={() => onChoose(c)}
            />
          </div>
        ))}
      </div>

      {/* —— 底部：上一题按钮（红色虚线左上方）+ 红色虚线 + 提示 —— */}
      <div className="mt-auto pt-2">
        {/* 上一题按钮：红色虚线之上、左对齐，稍微放大 */}
        <div className="mb-1.5">
          <button
            type="button"
            onClick={onPrev}
            disabled={num <= 1}
            className="border border-text1/70 bg-paper-50/40 px-2.5 py-1 font-serif text-[11.5px] tracking-wider text-text1 transition-opacity disabled:opacity-30"
          >
            ← 上一题
          </button>
        </div>
        <div className="border-t border-dashed border-ink-red" />
        <p className="mt-1 text-center font-serif text-[10px] leading-tight text-ink-red">
          请在各题目的答题区域内作答，超出黑色矩形边框限定区域的答案无效
        </p>
      </div>
    </div>
  );
}
