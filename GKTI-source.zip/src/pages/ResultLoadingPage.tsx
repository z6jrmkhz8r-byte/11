import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PencilProgressBar from '@/components/PencilProgressBar';
import { useQuizStore } from '@/store/useQuizStore';

/**
 * 试卷纸片飞舞背景：
 *   每张纸片随机起点（铺满整个画布的左下/中下区），
 *   随机飞行方向（向右上 / 左上 / 正上），
 *   随机旋转圈数与时长，无限循环，模拟"试卷被风吹飞旋转"。
 *
 * 数量与可见度针对"加载页主视觉"加强：
 *   - 数量从 12 → 28，密度提升 ~2.3 倍
 *   - 起点扩展到几乎整个画布，飞行轨迹更长
 *   - 纸片尺寸混合（小/中/大），peak opacity 从 0.95 维持但更长时间
 */
const PAPERS = 28;

interface PaperConf {
  left: number;
  top: number;
  flyX: number;
  flyY: number;
  flyR: number;
  duration: number;
  delay: number;
  scale: number;
}

function genPapers(): PaperConf[] {
  const rand = (min: number, max: number) => min + Math.random() * (max - min);
  return Array.from({ length: PAPERS }, () => {
    // 起点几乎铺满整个画布（除了顶部一点点 buffer）
    const left = rand(-5, 95);
    const top = rand(20, 100);
    // 飞行方向：右上 / 左上 / 偶尔正上
    const dir = Math.random();
    const flyX =
      dir > 0.6 ? rand(160, 320) : dir > 0.3 ? rand(-300, -140) : rand(-60, 60);
    return {
      left,
      top,
      flyX,
      flyY: rand(-360, -200),
      flyR: (Math.random() > 0.5 ? 1 : -1) * rand(360, 1080),
      duration: rand(1800, 3000),
      delay: rand(0, 2200),
      scale: rand(0.7, 1.4),
    };
  });
}

export default function ResultLoadingPage() {
  const nav = useNavigate();
  const [progress, setProgress] = useState(0);
  const [active, setActive] = useState(0);
  const computeResult = useQuizStore((s) => s.computeResult);

  const papers = useMemo(() => genPapers(), []);

  useEffect(() => {
    computeResult();
  }, [computeResult]);

  useEffect(() => {
    const t = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(t);
          setTimeout(() => nav('/result'), 400);
          return 100;
        }
        return p + 4;
      });
    }, 110);
    const a = setInterval(() => setActive((x) => (x + 1) % 4), 480);
    return () => {
      clearInterval(t);
      clearInterval(a);
    };
  }, [nav]);

  return (
    <div className="relative flex h-full flex-col">
      {/* —— 纸张吹飞旋转层（绝对层，覆盖整个内容区） —— */}
      <div className="paper-fly-stage" aria-hidden>
        {papers.map((p, i) => (
          <span
            key={i}
            className="pp"
            style={
              {
                left: `${p.left}%`,
                top: `${p.top}%`,
                ['--fly-x' as string]: `${p.flyX}px`,
                ['--fly-y' as string]: `${p.flyY}px`,
                ['--fly-r' as string]: `${p.flyR}deg`,
                ['--fly-d' as string]: `${p.duration}ms`,
                ['--fly-s' as string]: `${p.scale}`,
                animationDelay: `${p.delay}ms`,
              } as React.CSSProperties
            }
          />
        ))}
      </div>

      {/* —— 主内容（在纸片层之上） —— */}
      <div className="relative z-10 flex h-full flex-col pt-2">
        {/* 主标题 */}
        <div className="mt-6 text-center">
          <h2 className="font-serif text-[18px] font-bold tracking-[0.12em] text-text1">
            正在批改你的
          </h2>
          <div className="mt-2 inline-flex items-end gap-2">
            <h2 className="font-serif text-[26px] font-black tracking-[0.04em] text-ink-red">
              高考人格…
            </h2>
            <span className="mb-1 inline-block animate-bounce text-text1">
              <svg
                width="22"
                height="22"
                viewBox="0 0 22 22"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.4"
              >
                <path d="M3 19 L15 7 L17 9 L5 21 Z" fill="rgba(31,58,95,0.1)" />
              </svg>
            </span>
          </div>
        </div>

        {/* ABCD 方框（与答题卡涂卡格风格一致） */}
        <div className="mt-10 flex items-center justify-center gap-4">
          {['A', 'B', 'C', 'D'].map((l, i) => (
            <span
              key={l}
              className={`flex h-9 w-9 items-center justify-center border-2 font-mono text-[14px] font-bold transition-all duration-300 ${
                i === active
                  ? 'border-text1 bg-text1 text-paper-50 scale-110'
                  : 'border-text1/55 bg-white text-text1/55'
              }`}
              style={
                i === active
                  ? {
                      backgroundImage:
                        'repeating-linear-gradient(118deg, rgba(250,243,227,0.5) 0 1.5px, transparent 1.5px 4px)',
                    }
                  : {}
              }
            >
              {l}
            </span>
          ))}
        </div>

        {/* 进度条 */}
        <div className="mt-auto space-y-2">
          <div className="flex items-baseline justify-between font-serif text-[11px] text-text2">
            <span>批改进度</span>
            <span className="font-mono font-bold text-ink-red">{progress}%</span>
          </div>
          <PencilProgressBar progress={progress} />
          <p className="pt-0.5 text-center font-mono text-[9px] tracking-widest text-text3">
            PROCESSING · PLEASE WAIT
          </p>
        </div>
      </div>
    </div>
  );
}
