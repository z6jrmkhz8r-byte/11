import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  variant?: 'default' | 'exam';
  className?: string;
}

/** 复古纸卡：双线边框 + 四角小星 */
export default function PaperCard({ children, variant = 'default', className = '' }: Props) {
  const isExam = variant === 'exam';
  return (
    <div
      className={`relative bg-paper-50 paper-noise ${className}`}
      style={{
        boxShadow: isExam
          ? 'inset 0 0 0 1px #2B2113, inset 0 0 0 4px #FAF3E3, inset 0 0 0 5px #2B2113'
          : 'inset 0 0 0 1px #2B2113',
        padding: isExam ? '18px 16px' : '14px 14px',
      }}
    >
      {/* 四角装饰星 */}
      {isExam &&
        ['top-1.5 left-1.5', 'top-1.5 right-1.5', 'bottom-1.5 left-1.5', 'bottom-1.5 right-1.5'].map(
          (pos) => (
            <span key={pos} className={`absolute ${pos} text-[10px] text-ink-red`}>
              ★
            </span>
          ),
        )}
      <div className="relative z-10">{children}</div>
    </div>
  );
}
