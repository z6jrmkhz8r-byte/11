interface Props {
  total: number;
  /** 1-based */
  current: number;
  answered: Set<number>;
  /** 上一题回退后已答的题：用 done-quick 直接填涂，避免重新动画 */
  quickFilled?: Set<number>;
  onJump?: (n: number) => void;
}

export default function ProgressBar({
  total,
  current,
  answered,
  quickFilled,
  onJump,
}: Props) {
  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      <div className="border border-text1 bg-paper-50/60 px-1.5 py-[1px] font-mono text-[10.5px] tracking-wider text-text1">
        No.<span className="text-ink-red">{current}</span> / {total}
      </div>
      <div className="flex flex-wrap items-center gap-[3px]">
        {Array.from({ length: total }, (_, i) => i + 1).map((n) => {
          const isCur = n === current;
          const isDone = answered.has(n);
          const quick = quickFilled?.has(n);
          const cls = ['ap-cell'];
          if (isCur) cls.push('cur');
          if (isDone && !isCur) cls.push(quick ? 'done-quick' : 'done');
          return (
            <button
              key={n}
              type="button"
              onClick={() => onJump?.(n)}
              className={cls.join(' ')}
              style={{ cursor: onJump ? 'pointer' : 'default' }}
              aria-label={`第 ${n} 题`}
            >
              <span className="ap-cn relative z-10">{n}</span>
              {/* 与选项 qo-bubble 同款的 4 道铅笔笔迹（s1-s3 横向、s4 中央覆盖） */}
              <span className="ap-fill" aria-hidden>
                <span className="pen-stroke s1" />
                <span className="pen-stroke s2" />
                <span className="pen-stroke s3" />
                <span className="pen-stroke s4" />
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
