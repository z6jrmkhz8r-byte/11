import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  /** 桌面端 6 屏概览中使用：缩小展示 */
  scale?: number;
  label?: string;
  /** 移动端单屏模式：true 时铺满视口 */
  fullscreen?: boolean;
}

/**
 * 卡片容器
 * - PC 端：固定 360×720（或 scale 缩放）
 * - 移动端：通过 fullscreen 撑满 100dvh，并按比例计算卡片宽度
 * 内部内容统一使用 padding，留出边框装饰带空间
 */
export default function PhoneFrame({
  children,
  scale = 1,
  label,
  fullscreen,
}: Props) {
  return (
    <div
      className="flex flex-col items-center"
      style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }}
    >
      {label && (
        <div className="mb-2 flex items-center gap-2 self-start font-mono text-sm text-text1">
          <span className="inline-flex h-6 min-w-[26px] items-center justify-center bg-text1 px-1.5 text-paper-100">
            {label.split(' ')[0]}
          </span>
          <span className="text-text2">{label.split(' ').slice(1).join(' ')}</span>
        </div>
      )}
      <div
        className={`card-frame paper-noise relative ${
          fullscreen ? 'card-frame--full' : 'card-frame--fixed'
        }`}
      >
        {/* 内容安全区：避免与背景框红棕装饰带过近 */}
        <div className="relative h-full w-full px-7 py-7">{children}</div>
      </div>
    </div>
  );
}
