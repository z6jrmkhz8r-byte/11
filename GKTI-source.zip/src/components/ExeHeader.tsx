/** 顶部 .exe 风格小标题，所有内页通用 */
interface Props {
  text?: string;
}
export default function ExeHeader({ text = 'GKTI · 高考人格扫描器.exe' }: Props) {
  return (
    <div className="flex items-center justify-between border-b border-line/70 pb-2 pt-1">
      <span className="font-mono text-[12px] tracking-wide text-text2">{text}</span>
      <span className="font-mono text-text2">···</span>
    </div>
  );
}
