import { MouseEvent, useRef, useState } from 'react';

interface Props {
  label: 'A' | 'B' | 'C' | 'D';
  text: string;
  selected?: boolean;
  /** 回退展示用：跳过笔触动画，直接涂黑 */
  fastFill?: boolean;
  disabled?: boolean;
  onSelect?: (e: MouseEvent<HTMLButtonElement>) => void;
}

interface Ripple {
  id: number;
  x: number;
  y: number;
}

let rippleSeq = 0;

export default function QuizOption({
  label,
  text,
  selected,
  fastFill,
  disabled,
  onSelect,
}: Props) {
  const ref = useRef<HTMLButtonElement>(null);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [picking, setPicking] = useState(false);

  const handleClick = (e: MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;
    // ripple
    const rect = ref.current!.getBoundingClientRect();
    const id = ++rippleSeq;
    setRipples((r) => [...r, { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    setTimeout(() => setRipples((r) => r.filter((x) => x.id !== id)), 720);
    // optionPick 抖动
    setPicking(true);
    setTimeout(() => setPicking(false), 360);
    onSelect?.(e);
  };

  const cls = [
    'qo group relative flex w-full items-center gap-2.5 border px-2.5 py-2 text-left transition-colors',
    selected ? 'qo-selected border-text1' : 'border-line/70 hover:border-text1/80',
    fastFill ? 'qo-filled-quick' : '',
    picking ? 'option-pick' : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <button
      ref={ref}
      type="button"
      disabled={disabled}
      aria-pressed={selected}
      className={cls}
      style={{
        background: selected ? 'transparent' : 'rgba(250,243,227,0.4)',
        overflow: 'hidden',
      }}
      onClick={handleClick}
    >
      {/* 字母方框 [A] + 椭圆涂层（加宽避免方括号字符换行） */}
      <span className="qo-bracket relative flex h-9 w-11 shrink-0 items-center justify-center">
        {/* 椭圆涂黑层 */}
        <span className="qo-bubble" aria-hidden>
          <span className="pen-stroke s1" />
          <span className="pen-stroke s2" />
          <span className="pen-stroke s3" />
          <span className="pen-stroke s4" />
        </span>
        {/* [ A ] 字母 - 红色，禁止换行 */}
        <span
          className="qo-letter relative z-10 whitespace-nowrap font-mono text-[13px] font-bold tracking-tight"
          style={{ color: 'var(--ink-red)' }}
        >
          [ {label} ]
        </span>
      </span>

      <span
        className={`qo-text relative z-10 flex-1 font-serif text-[13px] leading-snug ${
          selected ? 'text-text1' : 'text-text1/85'
        }`}
      >
        {text}
      </span>

      {/* Ripple */}
      {ripples.map((r) => (
        <span
          key={r.id}
          className="ripple"
          style={{ left: r.x, top: r.y }}
          aria-hidden
        />
      ))}
    </button>
  );
}
