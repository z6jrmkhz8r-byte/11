/**
 * 答题卡头部信息区
 *
 * 三栏布局（左 / 中 / 右）：
 *  ┌──────────────┬──────────────┬─────────────┐
 *  │ 字段表（左）  │ 注意事项（中）│ 填涂样例（右）│
 *  │ 姓名 ……      │  注意事项    │  填涂样例    │
 *  │ 考场号 2026  │  1. 2B 铅笔  │  正确  ▮     │
 *  │ 座位号 14    │  2. 框内作答 │  错误 ⊘ × ∕  │
 *  │ 考生号 ……    │  3. 卡面整洁 │  贴条形码区  │
 *  └──────────────┴──────────────┴─────────────┘
 *
 * 设计要点：
 * - 4 行字段的 dashed-underline 宽度统一对齐到考生号长度（最长一行）；
 * - 填涂样例「正确」与「错误」使用相同尺寸的长方形示范框，
 *   正确框内复用 .ap-cell 的铅笔填涂动画做循环示范，
 *   错误框内放 ⊘ × ∕ 三个错误符号。
 */
interface Props {
  seat?: number;
}

/** 字段表中虚线占位的统一宽度（px），按考生号 GKTI20260614 长度对齐 */
const DASH_W = 88;

export default function AnswerCardHeader({ seat = 14 }: Props) {
  return (
    <div className="space-y-2">
      {/* —— 主标题 —— */}
      <div className="text-center">
        <h1 className="font-serif text-[14px] font-black tracking-[0.05em] text-text1">
          普通高等学校招生全国统一考试
        </h1>
        <p className="mt-0.5 font-serif text-[10.5px] tracking-[0.3em] text-text2">
          GKTI · 高考人格答题卡
        </p>
      </div>

      {/* —— 三栏信息区：左字段表自适应、中右两栏拉宽 —— */}
      <div className="grid grid-cols-[auto_1fr_1fr] items-start gap-x-2">
        {/* 左：字段表（4 行虚线宽度统一） */}
        <table className="font-serif text-[10.5px] text-text1">
          <tbody>
            <tr>
              <td
                className="whitespace-nowrap pr-2 align-middle"
                style={{ letterSpacing: '0.5em' }}
              >
                姓名
              </td>
              <td className="pb-0.5 pr-1 align-middle">
                <span
                  className="dashed-underline inline-block px-0 pb-0.5 font-serif text-[10.5px]"
                  style={{ width: DASH_W }}
                >
                  考　生
                </span>
              </td>
            </tr>
            <tr>
              <td className="whitespace-nowrap pr-2 pt-1 align-middle">
                考场号
              </td>
              <td className="pb-0.5 pr-1 pt-1 align-middle">
                <span
                  className="dashed-underline inline-block pb-0.5 font-mono text-[10.5px]"
                  style={{ width: DASH_W }}
                >
                  2026
                </span>
              </td>
            </tr>
            <tr>
              <td className="whitespace-nowrap pr-2 pt-1 align-middle">
                座位号
              </td>
              <td className="pb-0.5 pr-1 pt-1 align-middle">
                <span
                  className="dashed-underline inline-block pb-0.5 font-mono text-[10.5px]"
                  style={{ width: DASH_W }}
                >
                  {String(seat).padStart(2, '0')}
                </span>
              </td>
            </tr>
            <tr>
              <td className="whitespace-nowrap pr-2 pt-1 align-middle">
                考生号
              </td>
              <td className="pb-0.5 pr-1 pt-1 align-middle">
                <span
                  className="dashed-underline inline-block pb-0.5 font-mono text-[10px] tabular-nums"
                  style={{ width: DASH_W }}
                >
                  GKTI202606{String(seat).padStart(2, '0')}
                </span>
              </td>
            </tr>
          </tbody>
        </table>

        {/* 中：注意事项（适应性延长） */}
        <div className="flex w-full flex-col">
          <div className="border border-text1 bg-ink-red px-1 py-[2px] text-center font-serif text-[9px] tracking-[0.18em] text-paper-50">
            注意事项
          </div>
          <ol className="list-inside list-decimal space-y-0.5 border-x border-b border-text1 bg-paper-50/40 px-1.5 py-1 font-serif text-[8.5px] leading-tight text-text1">
            <li className="whitespace-nowrap">2B 铅笔填涂</li>
            <li className="whitespace-nowrap">框内作答</li>
            <li className="whitespace-nowrap">卡面整洁</li>
          </ol>
        </div>

        {/* 右：填涂样例（错误为 3 个独立等大方框 ⊘ / × / ∕；
            正确为单个同尺寸黑实心方框，对齐到第 1 个错误框正上方）+ 贴条形码区 */}
        <div className="flex w-full flex-col">
          <div className="border border-text1 bg-ink-red px-1 py-[2px] text-center font-serif text-[9px] tracking-[0.18em] text-paper-50">
            填涂样例
          </div>
          <div className="space-y-1 border-x border-b border-text1 bg-paper-50/40 px-1.5 py-1 font-serif text-[9px] text-text1">
            {/* 正确：单个 12×14 黑实心方框，左侧 label，方框对齐第一个错误小方框正上方 */}
            <div className="flex items-center gap-1">
              <span className="border border-ink-red px-0.5 text-[8.5px] leading-none text-ink-red">
                正确
              </span>
              <span className="ml-auto inline-flex items-center gap-[3px]">
                <span
                  className="inline-block bg-text1"
                  style={{ width: 12, height: 14 }}
                  aria-hidden
                />
                {/* 占位：与下方 2、3 个错误框对齐宽度，但视觉透明 */}
                <span
                  className="inline-block"
                  style={{ width: 12, height: 14 }}
                  aria-hidden
                />
                <span
                  className="inline-block"
                  style={{ width: 12, height: 14 }}
                  aria-hidden
                />
              </span>
            </div>
            {/* 错误：3 个独立的 12×14 等大方框，分别承载 ⊘ × ∕ */}
            <div className="flex items-center gap-1">
              <span className="border border-ink-red px-0.5 text-[8.5px] leading-none text-ink-red">
                错误
              </span>
              <span className="ml-auto inline-flex items-center gap-[3px] font-mono text-[9px] leading-none text-text1">
                <span
                  className="inline-flex items-center justify-center border border-text1 bg-white"
                  style={{ width: 12, height: 14 }}
                >
                  ⊘
                </span>
                <span
                  className="inline-flex items-center justify-center border border-text1 bg-white"
                  style={{ width: 12, height: 14 }}
                >
                  ×
                </span>
                <span
                  className="inline-flex items-center justify-center border border-text1 bg-white"
                  style={{ width: 12, height: 14 }}
                >
                  ∕
                </span>
              </span>
            </div>
          </div>

          {/* 贴条形码区 */}
          <div className="mt-0.5 flex h-[16px] items-center justify-center border border-dashed border-text2 px-0.5 font-serif text-[8px] tracking-[0.16em] text-text2">
            贴条形码区
          </div>
        </div>
      </div>
    </div>
  );
}
