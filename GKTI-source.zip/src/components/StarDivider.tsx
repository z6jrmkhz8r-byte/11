interface Props {
  text?: string;
  className?: string;
}

export default function StarDivider({ text, className = '' }: Props) {
  return (
    <div className={`star-divider ${className}`}>
      <span className="text-ink-red">★</span>
      {text && (
        <span className="font-serif text-[13px] tracking-[0.25em] text-ink-blue">
          {text}
        </span>
      )}
      <span className="text-ink-red">★</span>
    </div>
  );
}
