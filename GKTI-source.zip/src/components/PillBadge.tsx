import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  tilt?: 'l' | 'r' | 'none';
  variant?: 'red' | 'blue' | 'plain';
  className?: string;
}

/** Pill 徽章：用于 UP2AH!? / A4.exe 等人格代号、装饰 chip */
export default function PillBadge({
  children,
  tilt = 'none',
  variant = 'plain',
  className = '',
}: Props) {
  const color =
    variant === 'red'
      ? 'border-ink-red text-ink-red'
      : variant === 'blue'
      ? 'border-ink-blue text-ink-blue'
      : 'border-text1 text-text1';
  const tiltCls = tilt === 'l' ? 'tilt-l' : tilt === 'r' ? 'tilt-r' : '';
  return (
    <span
      className={`inline-flex items-center justify-center rounded-full border px-3 py-1 font-mono text-[12px] tracking-wide ${color} ${tiltCls} ${className}`}
      style={{ background: 'rgba(250,243,227,0.6)' }}
    >
      {children}
    </span>
  );
}
