interface Props {
  /** 0-100 */
  progress: number;
  blocks?: number;
}

export default function PencilProgressBar({ progress, blocks = 20 }: Props) {
  const filled = Math.round((progress / 100) * blocks);
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: blocks }).map((_, i) => (
        <span
          key={i}
          className="h-3.5 flex-1 transition-colors duration-200"
          style={{
            background: i < filled ? 'var(--ink-red)' : 'transparent',
            border: '1px solid var(--text-1)',
          }}
        />
      ))}
    </div>
  );
}
