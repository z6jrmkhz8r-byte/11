interface Props {
  label: string;
  value: string;
  /** 字段名两字间空一格效果 */
  spaced?: boolean;
}

/** 准考证下划线填空字段 */
export default function DashedField({ label, value, spaced }: Props) {
  return (
    <div className="flex items-center gap-3 py-2">
      <span
        className="shrink-0 font-serif text-[15px] text-text1"
        style={{ letterSpacing: spaced ? '0.6em' : 'normal', paddingRight: spaced ? 0 : 4 }}
      >
        {label}
      </span>
      <span className="dashed-underline relative flex-1 pb-1 font-serif text-[15px] text-text1">
        {value}
      </span>
    </div>
  );
}
