import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

/**
 * 切屏遮罩：路由变化时
 *  - 0ms 立刻显示 (.show)
 *  - 160ms 后子页面已经切换（路由切换由 Router 驱动）
 *  - 220ms 后移除 .show 触发 fade out
 *  共 ~520ms 可见时长（与 transition 300ms 相加）
 */
export default function TransitionMask() {
  const location = useLocation();
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(true);
    const t1 = window.setTimeout(() => setShow(false), 220);
    return () => window.clearTimeout(t1);
  }, [location.pathname]);

  return <div className={`transition-mask ${show ? 'show' : ''}`} aria-hidden />;
}
