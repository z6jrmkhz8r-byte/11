import { ReactNode, ButtonHTMLAttributes } from 'react';

type Variant = 'red' | 'blue' | 'ghost';

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  children: ReactNode;
  block?: boolean;
}

const styles: Record<Variant, string> = {
  red: 'bg-ink-red text-paper-50 active:translate-y-px',
  blue: 'bg-ink-blue text-paper-50 active:translate-y-px',
  ghost: 'bg-transparent text-text1 border border-text1 active:translate-y-px',
};

export default function PrimaryButton({
  variant = 'red',
  block,
  children,
  className = '',
  ...rest
}: Props) {
  return (
    <button
      {...rest}
      className={`relative inline-flex items-center justify-center gap-2 px-5 py-3 font-serif text-[16px] font-bold tracking-[0.18em] transition-transform ${
        styles[variant]
      } ${block ? 'w-full' : ''} ${className}`}
      style={{
        boxShadow:
          variant === 'ghost'
            ? 'none'
            : 'inset 0 0 0 1px rgba(250,243,227,0.55), 0 2px 0 rgba(0,0,0,0.18)',
      }}
    >
      {/* 内层细边线（双层做旧感） */}
      {variant !== 'ghost' && (
        <span
          aria-hidden
          className="pointer-events-none absolute inset-1 border border-paper-50/45"
        />
      )}
      <span className="relative z-10">{children}</span>
    </button>
  );
}
