interface Props {
  text: string;
  rotate?: number;
  size?: 'sm' | 'md';
}

export default function StampSeal({ text, rotate = -6, size = 'md' }: Props) {
  const sz = size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-1';
  return (
    <span
      className={`stamp-red inline-block font-mono font-bold tracking-widest ${sz}`}
      style={{
        transform: `rotate(${rotate}deg)`,
        opacity: 0.85,
      }}
    >
      {text}
    </span>
  );
}
