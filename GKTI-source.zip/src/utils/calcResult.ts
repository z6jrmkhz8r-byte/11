import { Choice, QUESTIONS } from '@/data/questions';
import { pickPersonality, Personality } from '@/data/personalities';

export function calcResult(answers: Record<number, Choice>): Personality {
  const score = { O: 0, T: 0, M: 0, P: 0, S: 0 };
  for (const q of QUESTIONS) {
    const c = answers[q.id];
    if (!c) continue;
    const idx = ['A', 'B', 'C', 'D'].indexOf(c);
    const w = q.weights[idx] ?? 0;
    score[q.dim] += w;
  }
  return pickPersonality(score);
}
