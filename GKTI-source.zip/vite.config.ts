import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import path from 'node:path';

/**
 * 双模式构建：
 *  - dev / 普通 vite build：保持原行为（多文件 SPA，外链 JS/CSS）
 *  - SINGLE_FILE=1 vite build：把所有 JS/CSS/资源内联进单个 HTML。
 *    并使用 IIFE 格式输出，避免 ES Module 不被某些预览平台支持的问题。
 */
const SINGLE_FILE = process.env.SINGLE_FILE === '1';

export default defineConfig({
  base: './',
  plugins: [
    react(),
    ...(SINGLE_FILE ? [viteSingleFile()] : []),
  ],
  resolve: {
    alias: { '@': path.resolve(__dirname, 'src') },
  },
  server: { host: '0.0.0.0', port: 5173 },
  build: {
    target: 'es2017',
    cssCodeSplit: !SINGLE_FILE,
    assetsInlineLimit: SINGLE_FILE ? 100 * 1024 * 1024 : 4096,
    // SINGLE_FILE 模式：用 IIFE 输出（无 type="module"），最大化兼容老内嵌环境
    rollupOptions: SINGLE_FILE
      ? {
          output: {
            format: 'iife',
            inlineDynamicImports: true,
            entryFileNames: 'app.js',
            assetFileNames: 'app.[ext]',
            manualChunks: undefined,
          },
        }
      : undefined,
  },
});
